# CS-2720-Final-Project
Image Viewer Application

A user creates an account linked to an online SQL database, logs in and can upload, delete or save images accordingly in a viewing panel. There is also an option to greyscale the image if desired.
